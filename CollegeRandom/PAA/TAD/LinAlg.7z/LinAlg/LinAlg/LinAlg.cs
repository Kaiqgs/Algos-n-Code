﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinAlg
{
    public static class LinAlg
    {
        public static float[,] MatMul(this float[,] self, float[,] data)
        {
            float[,] out_obj = null;

            if (self.GetLength(1) != data.GetLength(0))
                throw new ArrayTypeMismatchException($@"Array provided is not of equal inner size,
                                                     [{self.GetLength(0)},{self.GetLength(1)}] x [{data.GetLength(0)},{data.GetLength(1)}]");


            
            out_obj = new float[self.GetLength(0), data.GetLength(1)];
            
            float temp = default(float);

            for (int i = 0; i < self.GetLength(0); i++)
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    temp = 0;
                    for (int k = 0; k < self.GetLength(1); k++)
                        temp += self[i, k] * data[k, j];
                    
                    out_obj[i, j] = temp;
                }
            
            return out_obj;
        }

        public static void Add(this ref float[,] self, float b)
        {
            for (int i = 0; i < self.GetLength(0); i++)
                for (int j = 0; j < self.GetLength(1); j++)
                    self[i, j] += b;
        }
    }
}
